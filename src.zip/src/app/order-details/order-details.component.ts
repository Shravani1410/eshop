import { Component, OnInit } from '@angular/core';
import { Order } from './order-model';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
  order: Order = {
    fullName: '',
    email: '',
    address: '',
    contactNumber: 0
  };
  productId!: string;
  formSubmitted = false; // Flag variable to track form submission

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.productId = params.get('productId')!;
    });
  }

  isFormEmpty(): boolean {
    return (
      !this.order.fullName ||
      !this.order.email ||
      !this.order.contactNumber ||
      !this.order.address
    );
  }

  submitOrder(): void {
    if (this.isFormEmpty()) {
      console.log('Please fill in all the required fields.');
      this.formSubmitted = true; // Set the flag to true
      return; // Stop form submission
    }

    if (!this.order.address.trim()) {
      console.log('Please enter a valid address.');
      this.formSubmitted = true; // Set the flag to true
      return; // Stop form submission
    }

    // Include the productId in the order payload
    const orderPayload = {
      ...this.order,
      productId: this.productId
    };

    // Send the order data to the backend API
    this.http
      .post('http://localhost:8084/api/v1/orderdetails/placeorder', orderPayload)
      .subscribe(
        () => {
          console.log('Order submitted successfully');
          // You can perform any additional actions here after successful submission
          this.router.navigate(['/order-page']); // Navigate to the next page
        },
        error => {
          console.error('Failed to submit order', error);
          // Handle error here if needed
        }
      );
  }
  cancelOrder(){
    this.router.navigate(['/']);
  }
}
{

}
