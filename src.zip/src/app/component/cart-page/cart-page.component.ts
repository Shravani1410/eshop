import { Component, OnInit } from '@angular/core';
import { product } from 'src/app/product-view/product-model';
import { ApiService } from 'src/app/shared/api.service';
import{FormControl,FormGroup,Validators}from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit{
  showproduct:any=[];
  public totalamount:number=0;
  public addressform=false;
  myform:FormGroup|any;
  constructor(private api:ApiService, private router: Router){}
  ngOnInit(): void {
    this.api.products().subscribe(res=>{
      this.showproduct =res;
      this.totalamount=this.api.calculateprice();
      console.log("total amount is",this.totalamount)
    })
    this.myform=new FormGroup({
      email:new FormControl('',Validators.required),
      name:new FormControl('',Validators.required),
      mobile:new FormControl('',Validators.required),
      address:new FormControl('',Validators.required)
    })
  }
  deleteitem(item:product){
    this.api.removecartitem(item)

  }
  Empty(){
    this.api.removeallitem()
  }
  checkout() {
    const productId = this.showproduct[0].productid;
    this.router.navigate(['/order-detail', productId]);
  }

}
