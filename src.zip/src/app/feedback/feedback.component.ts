import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent {
  name: string ="";
  email: string = "";
  feedback: string = "";
  
  
  constructor(private http: HttpClient )
  {
  }
  save()
  {
  
    let bodyData = {
     "name": this.name,
     "email": this.email,
     "feedback": this.feedback
     

    };
    this.http.post("http://localhost:8084/api/v1/feedback/save",bodyData,{responseType: 'text'}).subscribe((resultData: any)=>
    {
        console.log(resultData);
        alert("Feedback Sended Successfully");
    });
  }
}
