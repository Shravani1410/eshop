export  interface feedback{
    id: number;
    name:string;
    email:string;
    feedback:string;

}