export interface Order {
    orderid: number;
    fullName: string;
    contactNumber: string;
    email: string;
    address: string;
  }
  