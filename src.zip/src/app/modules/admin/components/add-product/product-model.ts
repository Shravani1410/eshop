export interface product {
    productid: number;
    itemName: string;
    description: string;
    price: number;
    quantity:number;
    categoryName: string;
    image: string;
  }