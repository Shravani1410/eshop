export  interface customer{
    
    name:string;
    email:string;
    password:string;
    cpassword:string;

}