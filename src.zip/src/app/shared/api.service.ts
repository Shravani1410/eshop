import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {BehaviorSubject}from 'rxjs';
import { product } from '../product-view/product-model';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  getfeedback() {
    return this.http.get<product[]>("http://localhost:8084/api/v1/feedback/getAllfeedback")
  }
  public cartitemlist:any=[];
  public productlist =new BehaviorSubject<any>([])
  constructor(private http:HttpClient) { }
  getproduct(){
   return this.http.get<product[]>("http://localhost:8084/api/v1/product/getAllproduct")
  }
  getproductbyid(id:string){
    return this.http.get(`http://localhost:8084/api/v1/product/getproductbyid/${id}`)
  }
  addtocart(data:product){
    this.cartitemlist.push(data);
    this.productlist.next(this.cartitemlist);
    console.log(this.cartitemlist);
  }
  products(){
    return this.productlist.asObservable();
  }
  removecartitem(data:product){
    this.cartitemlist.map((a:product,index:product)=>{
      if(data.productid === a.productid){
        this.cartitemlist.splice(index,1)

      }
    })
    this.productlist.next(this.cartitemlist)
  }

 
  calculateprice(){
    let total=0;
    this.cartitemlist.map((a:any)=>{
      total+=a.price;
    })
    return total;
  }
 
  removeallitem(){
    this.cartitemlist=[];
    this.productlist.next(this.cartitemlist)
  }
}
